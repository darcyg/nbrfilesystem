/*
 * Mesa 3-D graphics library MiniGUI bindings.
 * Version:  1.0
 * Copyright (C) 1995-1998  Brian Paul
 * Copyright (C) 2006 Feynman Software
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

#ifndef MGMESA_H
#define MGMESA_H

#include <minigui/common.h>
#include <minigui/minigui.h>
#include <minigui/gdi.h>
#include <minigui/window.h>
#include <minigui/control.h>

#include "GL/gl.h"

#ifdef __cplusplus
extern "C" {
#endif

/*
 * This is the mgMesa context 'handle':
 */
typedef struct mgmesa_context *mgMesaContext;


/*
 * Create a new mgMesaContext for rendering into a window.  You must
 * have already created the window of correct visual type and with an
 * appropriate colormap.
 *
 * Input:
 *         hDC - Windows device or memory context
 *         Pal  - Palette to use
 *         rgb_flag - GL_TRUE = RGB mode,
 *                    GL_FALSE = color index mode
 *         db_flag - GL_TRUE = double-buffered,
 *                   GL_FALSE = single buffered
 *         alpha_flag - GL_TRUE = create software alpha buffer,
 *                      GL_FALSE = no software alpha buffer
 *
 * Note: Indexed mode requires double buffering under Windows.
 *
 * Return:  a mgMesa_context or NULL if error.
 */
extern mgMesaContext mgMesaCreateContext(HDC hDC,HPALETTE* pPal,
                                       GLboolean rgb_flag,
                                       GLboolean db_flag,
                                       GLboolean alpha_flag);


/*
 * Destroy a rendering context as returned by mgMesaCreateContext()
 */
extern void mgMesaDestroyContext( mgMesaContext ctx );



/*
 * Make the specified context the current one.
 */
extern void mgMesaMakeCurrent( mgMesaContext ctx, HDC hdc );


/*
 * Return a handle to the current context.
 */
extern mgMesaContext mgMesaGetCurrentContext( void );


/*
 * Swap the front and back buffers for the current context.  No action
 * taken if the context is not double buffered.
 */
extern void mgMesaSwapBuffers(HDC hdc);


/*
 * In indexed color mode we need to know when the palette changes.
 */
extern void mgMesaPaletteChange(HPALETTE Pal);

extern void mgMesaMove(void);

#ifdef __cplusplus
}
#endif

#endif /* MGMESA_H */

