/* gears.c */

/*
 * 3-D gear wheels.  This program is in the public domain.
 *
 * Brian Paul
 * modified by Uwe Maurer (uwe_maurer@t-online.de)
 */

#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <assert.h>

#include <minigui/common.h>
#include <minigui/minigui.h>
#include <minigui/gdi.h>
#include <minigui/window.h>

#include <GL/gl.h>
#include <GL/mgmesa.h>
#include <math.h>

#ifndef M_PI
#  define M_PI 3.14159265
#endif

static mgMesaContext mesa_ctx;
static HDC mesa_dc;

char text[100];
int db_flag, vis_x, vis_y, vir_x, vir_y;

/*
 * Draw a gear wheel.  You'll probably want to call this function when
 * building a display list since we do a lot of trig here.
 *
 * Input:  inner_radius - radius of hole at center
 *         outer_radius - radius at center of teeth
 *         width - width of gear
 *         teeth - number of teeth
 *         tooth_depth - depth of tooth
 */
static void gear( GLfloat inner_radius, GLfloat outer_radius, GLfloat width,
                  GLint teeth, GLfloat tooth_depth )
{
    GLint i;
    GLfloat r0, r1, r2;
    GLfloat angle, da;
    GLfloat u, v, len;

    r0 = inner_radius;
    r1 = outer_radius - tooth_depth/2.0;
    r2 = outer_radius + tooth_depth/2.0;

    da = 2.0*M_PI / teeth / 4.0;

    glShadeModel( GL_FLAT );

    glNormal3f( 0.0, 0.0, 1.0 );

    /* draw front face */
    glBegin( GL_QUAD_STRIP );
    for (i=0;i<=teeth;i++) {
        angle = i * 2.0*M_PI / teeth;
        glVertex3f( r0*cos(angle), r0*sin(angle), width*0.5 );
        glVertex3f( r1*cos(angle), r1*sin(angle), width*0.5 );
        glVertex3f( r0*cos(angle), r0*sin(angle), width*0.5 );
        glVertex3f( r1*cos(angle+3*da), r1*sin(angle+3*da), width*0.5 );
    }
    glEnd();

    /* draw front sides of teeth */
    glBegin( GL_QUADS );
    da = 2.0*M_PI / teeth / 4.0;
    for (i=0;i<teeth;i++) {
        angle = i * 2.0*M_PI / teeth;

        glVertex3f( r1*cos(angle),        r1*sin(angle),        width*0.5 );
        glVertex3f( r2*cos(angle+da),    r2*sin(angle+da),    width*0.5 );
        glVertex3f( r2*cos(angle+2*da), r2*sin(angle+2*da), width*0.5 );
        glVertex3f( r1*cos(angle+3*da), r1*sin(angle+3*da), width*0.5 );
    }
    glEnd();


    glNormal3f( 0.0, 0.0, -1.0 );

    /* draw back face */
    glBegin( GL_QUAD_STRIP );
    for (i=0;i<=teeth;i++) {
        angle = i * 2.0*M_PI / teeth;
        glVertex3f( r1*cos(angle), r1*sin(angle), -width*0.5 );
        glVertex3f( r0*cos(angle), r0*sin(angle), -width*0.5 );
        glVertex3f( r1*cos(angle+3*da), r1*sin(angle+3*da), -width*0.5 );
        glVertex3f( r0*cos(angle), r0*sin(angle), -width*0.5 );
    }
    glEnd();

    /* draw back sides of teeth */
    glBegin( GL_QUADS );
    da = 2.0*M_PI / teeth / 4.0;
    for (i=0;i<teeth;i++) {
        angle = i * 2.0*M_PI / teeth;

        glVertex3f( r1*cos(angle+3*da), r1*sin(angle+3*da), -width*0.5 );
        glVertex3f( r2*cos(angle+2*da), r2*sin(angle+2*da), -width*0.5 );
        glVertex3f( r2*cos(angle+da),    r2*sin(angle+da),    -width*0.5 );
        glVertex3f( r1*cos(angle),        r1*sin(angle),        -width*0.5 );
    }
    glEnd();


    /* draw outward faces of teeth */
    glBegin( GL_QUAD_STRIP );
    for (i=0;i<teeth;i++) {
        angle = i * 2.0*M_PI / teeth;

        glVertex3f( r1*cos(angle),        r1*sin(angle),         width*0.5 );
        glVertex3f( r1*cos(angle),        r1*sin(angle),        -width*0.5 );
        u = r2*cos(angle+da) - r1*cos(angle);
        v = r2*sin(angle+da) - r1*sin(angle);
        len = sqrt( u*u + v*v );
        u /= len;
        v /= len;
        glNormal3f( v, -u, 0.0 );
        glVertex3f( r2*cos(angle+da),    r2*sin(angle+da),     width*0.5 );
        glVertex3f( r2*cos(angle+da),    r2*sin(angle+da),    -width*0.5 );
        glNormal3f( cos(angle), sin(angle), 0.0 );
        glVertex3f( r2*cos(angle+2*da), r2*sin(angle+2*da),  width*0.5 );
        glVertex3f( r2*cos(angle+2*da), r2*sin(angle+2*da), -width*0.5 );
        u = r1*cos(angle+3*da) - r2*cos(angle+2*da);
        v = r1*sin(angle+3*da) - r2*sin(angle+2*da);
        glNormal3f( v, -u, 0.0 );
        glVertex3f( r1*cos(angle+3*da), r1*sin(angle+3*da),  width*0.5 );
        glVertex3f( r1*cos(angle+3*da), r1*sin(angle+3*da), -width*0.5 );
        glNormal3f( cos(angle), sin(angle), 0.0 );
    }

    glVertex3f( r1*cos(0), r1*sin(0), width*0.5 );
    glVertex3f( r1*cos(0), r1*sin(0), -width*0.5 );

    glEnd();


    glShadeModel( GL_SMOOTH );

    /* draw inside radius cylinder */
    glBegin( GL_QUAD_STRIP );
    for (i=0;i<=teeth;i++) {
        angle = i * 2.0*M_PI / teeth;
        glNormal3f( -cos(angle), -sin(angle), 0.0 );
        glVertex3f( r0*cos(angle), r0*sin(angle), -width*0.5 );
        glVertex3f( r0*cos(angle), r0*sin(angle), width*0.5 );
    }
    glEnd();
        
}


static GLfloat view_rotx=20.0, view_roty=30.0, view_rotz=0.0;
static GLint gear1, gear2, gear3;
static GLfloat angle = 0.0;

static GLuint limit;
static GLuint count = 1;


static void draw( void )
{
    static int n = 0;
    glClearColor(0,0,0,0);
    glClearIndex(0);
    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

    glPushMatrix();
    glRotatef( view_rotx, 1.0, 0.0, 0.0 );
    glRotatef( view_roty, 0.0, 1.0, 0.0 );
    glRotatef( view_rotz, 0.0, 0.0, 1.0 );

    glPushMatrix();
    glTranslatef( -3.0, -2.0, 0.0 );
    glRotatef( angle, 0.0, 0.0, 1.0 );
    glCallList(gear1);
    glPopMatrix();

    glPushMatrix();
    glTranslatef( 3.1, -2.0, 0.0 );
    glRotatef( -2.0*angle-9.0, 0.0, 0.0, 1.0 );
    glCallList(gear2);
    glPopMatrix();

    glPushMatrix();
    glTranslatef( -3.1, 4.2, 0.0 );
    glRotatef( -2.0*angle-25.0, 0.0, 0.0, 1.0 );
    glCallList(gear3);
    glPopMatrix();

    glPopMatrix();
    glFlush();
    glFinish();

#if 0
    ggiSetGCForeground(vis,255);
    ggiPuts(vis,0,0,"Mesa  ->  GGI");
    ggiPuts(vis,0,ggiGetInfo(vis)->mode->visible.y," Mesa -> GGI");

    ggiPuts(vis,0,16,text);
    ggiPuts(vis,0,ggiGetInfo(vis)->mode->visible.y+16,text);
#endif

    if (db_flag)
        mgMesaSwapBuffers (mesa_dc);
                         
    count++;
    if (count==limit) {
        exit(1);
    }
    ++n;

     /*
    if (!(n%10)){
        ggi_color rgb = { 10000, 10000, 10000 };
        ggiSetSimpleMode(vis,vis_x+(n/10),vis_y+(n/10),db_flag?2:1, gt); 
        glViewport(0, 0,vis_x+(n/10),vis_y+(n/10));
        ggiSetGCForeground(vis, ggiMapColor(vis, &rgb));
        ggiDrawBox(vis, 20, 20, 100, 100);
        if(db_flag)
          ggiSetWriteFrame(vis, 1);
     }
     */
}

static void idle (HWND hwnd)
{
    angle += 2.0;
    InvalidateRect (hwnd, NULL, FALSE);
}

/* new window size or exposure */
static void reshape( int width, int height )
{
    GLfloat  h = (GLfloat) height / (GLfloat) width;

    if (db_flag)
        glDrawBuffer(GL_BACK);
    else
        glDrawBuffer(GL_FRONT);

    glViewport(0, 0, (GLint)width, (GLint)height);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glFrustum( -1.0, 1.0, -h, h, 5.0, 60.0 );
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glTranslatef( 0.0, 0.0, -40.0 );
    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
}

static void init( void )
{
    static GLfloat pos[4] = {5.0, 5.0, 10.0, 0.0 };
    static GLfloat red[4] = {1.0, 0.0, 0.0, 1.0 };
    static GLfloat green[4] = {0.0, 1.0, 0.0, 1.0 };
    static GLfloat blue[4] = {0.0, 0.0, 1.0, 1.0 };

    glLightfv( GL_LIGHT0, GL_POSITION, pos );
    glEnable( GL_CULL_FACE );
    glEnable( GL_LIGHTING );
    glEnable( GL_LIGHT0 );
    glEnable( GL_DEPTH_TEST );

    /* make the gears */
    gear1 = glGenLists(1);
    glNewList(gear1, GL_COMPILE);
    glMaterialfv( GL_FRONT, GL_AMBIENT_AND_DIFFUSE, red );
    glIndexi(1);
    gear( 1.0, 4.0, 1.0, 20, 0.7 );
    glEndList();

    gear2 = glGenLists(1);
    glNewList(gear2, GL_COMPILE);
    glMaterialfv( GL_FRONT, GL_AMBIENT_AND_DIFFUSE, green );
    glIndexi(2);
    gear( 0.5, 2.0, 2.0, 10, 0.7 );
    glEndList();

    gear3 = glGenLists(1);
    glNewList(gear3, GL_COMPILE);
    glMaterialfv( GL_FRONT, GL_AMBIENT_AND_DIFFUSE, blue );
    glIndexi(3);
    gear( 1.3, 2.0, 0.5, 10, 0.7 );
    glEndList();

    glEnable( GL_NORMALIZE );
}

static int Mesa3DWinProc(HWND hWnd, int message, WPARAM wParam, LPARAM lParam)
{
    HDC hdc;

    switch (message) {
        case MSG_CREATE:
            SetTimer (hWnd, 100, 10);
            break;

        case MSG_PAINT:
            hdc = BeginPaint (hWnd);
            draw ();
            EndPaint (hWnd, hdc);
            return 0;

#if 1
        case MSG_TIMER:
            idle (hWnd);
            break;
#else
        case MSG_IDLE:
            idle (hWnd);
            break;
#endif

        case MSG_CSIZECHANGED:
            reshape (wParam, lParam);
            break;

        case MSG_CLOSE:
            KillTimer (hWnd, 100);
            DestroyMainWindow (hWnd);
            PostQuitMessage (hWnd);
            return 0;
    }

    return DefaultMainWinProc(hWnd, message, wParam, lParam);
}

static void init_minigui_mesa ()
{
    mesa_ctx = mgMesaCreateContext (mesa_dc, NULL, GL_TRUE, db_flag, GL_FALSE);
    assert(mesa_ctx);

    mgMesaMakeCurrent (mesa_ctx, mesa_dc);
}

static void deinit_minigui_mesa ()
{
    mgMesaMakeCurrent (NULL, 0);

    mgMesaDestroyContext (mesa_ctx);
}

int MiniGUIMain (int argc, const char* argv[])
{
    MSG Msg;
    HWND hMainWnd;
    MAINWINCREATE CreateInfo;
    RECT rc;

#ifdef _MGRM_PROCESSES
    JoinLayer(NAME_TOPMOST_LAYER, "gears" , 0 , 0);
#endif

    db_flag = 1;
    vis_x = 320;
    vis_y = 240;
    vir_x = 400;
    vir_y = 360;

    CreateInfo.dwStyle = WS_VISIBLE | WS_BORDER | WS_CAPTION;
    CreateInfo.dwExStyle = WS_EX_USEPRIVATECDC;
    CreateInfo.spCaption = "OpenGL Gears!";
    CreateInfo.hMenu = 0;
    CreateInfo.hCursor = GetSystemCursor(0);
    CreateInfo.hIcon = 0;
    CreateInfo.MainWindowProc = Mesa3DWinProc;
    CreateInfo.lx = 0;
    CreateInfo.ty = 0;
    CreateInfo.rx = vis_x;
    CreateInfo.by = vis_y;
    CreateInfo.iBkColor = COLOR_lightwhite;
    CreateInfo.dwAddData = 0;
    CreateInfo.hHosting = HWND_DESKTOP;
    
    hMainWnd = CreateMainWindow (&CreateInfo);
    
    if (hMainWnd == HWND_INVALID)
        return -1;

    ShowWindow(hMainWnd, SW_SHOWNORMAL);

    mesa_dc = GetPrivateClientDC (hMainWnd);

    init_minigui_mesa ();

    GetClientRect (hMainWnd, &rc);
    reshape (RECTW (rc), RECTH (rc));

    init ();

    while (GetMessage(&Msg, hMainWnd)) {
        TranslateMessage(&Msg);
        DispatchMessage(&Msg);
    }

    MainWindowThreadCleanup (hMainWnd);

    deinit_minigui_mesa ();

    return 0;
}

#ifndef _LITE_VERSION
#include <minigui/dti.c>
#endif

