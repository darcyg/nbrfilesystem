#ifndef XUSEROTFONT_H
#define XUSEROTFONT_H

#include <X11/Xlib.h>


extern void
glXUseRotatedXFontMESA(Font font, int first, int count, int listbase,
                       int rotation);


#endif
